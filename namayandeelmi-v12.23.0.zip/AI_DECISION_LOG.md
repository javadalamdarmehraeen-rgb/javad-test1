## 11.77.0
تب قیمت‌گذاری کالاها با دو کادر فعلی/جدید و اعمال زمان‌بندی‌شده.

## 11.76.0
آرشیو فایل پخش/اسنپ قفل شد؛ Autofill جغرافیا قطع؛ نام داروخانه ساده؛ هیت‌مپ فعالیت.

# AI DECISION LOG
# Namayande Elmi

This document records verified historical development decisions and
important architectural changes reconstructed from the Git repository.

IMPORTANT:

This document must distinguish between:

1. VERIFIED FACT
   Confirmed directly from Git history, source code, or existing project documentation.

2. INFERENCE
   A reasonable interpretation of multiple verified facts.

3. UNKNOWN
   Information that cannot currently be recovered.

Never convert an inference or assumption into a verified fact.

---

# 1. PURPOSE

The original project was developed through multiple AI-assisted sessions.

The original conversational history is currently unavailable/incomplete.

Therefore this document reconstructs the project's historical evolution
from:

- Git commit history
- source files
- existing change logs
- AI_PROJECT_CONTEXT.md
- AI_ARCHITECTURE.md
- repository structure

The goal is to prevent future AI agents from destroying working functionality
because they do not know why previous changes were made.

---

# 2. HISTORICAL RECOVERY STATUS

Status:

PARTIALLY RECOVERED

The Git repository preserves a significant portion of the implementation
history.

However, Git commit messages do not preserve the complete reasoning behind
every decision.

Therefore:

VERIFIED:
What changed.

UNKNOWN:
Why every change was requested.

UNKNOWN:
Which previous AI prompt originally requested each change.

UNKNOWN:
Which alternatives were considered and rejected.

---

# 3. DEVELOPMENT PHASE — V5

Commit:

Deploy v5.0.0 Zero Horizontal Scroll UI with compact wrapping pills and Launchpad

Verified from Git history.

Major themes:

- Zero horizontal scroll UI
- Compact wrapping pills
- Launchpad

Interpretation:

The project was already undergoing significant UI/UX customization by V5.

---

# 4. DEVELOPMENT PHASE — V6

Commit:

Deploy v6.0.0 Ultimate CRM with all 12 historical prompt requirements

Verified from Git history.

Major theme:

The V6 release explicitly refers to 12 historical prompt requirements.

This confirms that previous AI/user conversations had already accumulated
multiple requirements that were being preserved in the implementation.

IMPORTANT:

The exact 12 historical prompts are not fully reconstructed by this document.

Status:

VERIFIED:
There were 12 historical prompt requirements referenced by the V6 commit.

UNKNOWN:
The complete original wording and reasoning of all 12 prompts.

---

# 5. DEVELOPMENT PHASE — V7

Commit:

Deploy v7.0.0 Ultimate CRM with live Gregorian date badge and all historical prompts

Verified from Git history.

Major themes:

- Ultimate CRM
- Live Gregorian date badge
- Historical prompt requirements

Interpretation:

V7 extended the previously accumulated CRM requirements rather than
starting a new independent application.

---

# 6. DEVELOPMENT PHASE — V8

Commit:

Deploy v8.0.0 Ultimate CRM matching Ultra-Professional Master Specification

Verified from Git history.

Major theme:

The CRM was being aligned with a larger master specification.

This represents an important expansion of the application's functional scope.

The V8 development included multiple CRM capabilities and supporting
functionality.

The exact original "Ultra-Professional Master Specification" document is
not currently available in the recovered conversation.

Therefore:

VERIFIED:
V8 was explicitly intended to match that specification.

UNKNOWN:
The complete original specification text.

---

# 7. DEVELOPMENT PHASE — V9

V9 is part of the versioned CRM feature architecture.

The repository contains:

public/crm-features-v9.js

The exact complete reasoning behind V9 is not yet reconstructed.

Do not remove V9 simply because newer feature files exist.

---

# 8. DEVELOPMENT PHASE — V10

V10 represents an important architectural/functional phase.

Existing repository history includes:

CHANGES_V10.md

The V10 changes include verified themes such as:

- Separate login page
- /login
- /panel
- Local Leaflet usage
- Removal of Google Font dependency
- gzip compression for JS/CSS/HTML
- Form/list behavior changes
- Location behavior
- Dashboard widget management
- Medical/facility data
- Diagnostic functionality

IMPORTANT:

V10 is not merely a visual redesign.

It introduced or consolidated multiple runtime and CRM behaviors.

---

# 9. DEVELOPMENT PHASE — V11.0

Commit:

v11.0.0 password change, visit track, bordered excel, real row numbers

Commit SHA:

b313dcd

Verified changes:

- Password change
- Visit tracking
- Bordered Excel
- Real row numbers

Interpretation:

V11 began a new phase of detailed CRM functionality and data-entry/reporting
behavior.

---

# 10. DEVELOPMENT PHASE — V11.1

Commit:

v11.1.0 columns tab picker, field order, product name visible

Commit SHA:

04439a5

Verified themes:

- Columns tab picker
- Field order
- Product name visibility

This is one of the first clearly documented steps toward the current
customizable field/form/list architecture.

---

# 11. DEVELOPMENT PHASE — V11.2

Commit:

v11.2.0 all tab fields, edit/delete on real form, products in orders with gift

Commit SHA:

de77c8d

Verified themes:

- All tab fields
- Edit/delete on real form
- Products in orders
- Gift quantity/product functionality

The CRM form system became increasingly tied to real operational data.

---

# 12. DEVELOPMENT PHASE — V11.3

Commit:

v11.3.0 row-order, move, field size, show in form/list

Commit SHA:

cf8d3c4

Verified themes:

- Row order
- Field movement
- Field size
- Show in form
- Show in list

This confirms that field configuration is not merely cosmetic.

Field placement and visibility are part of the functional CRM behavior.

---

# 13. DEVELOPMENT PHASE — V11.3.1

Commit:

v11.3.1 restore columns tab grid after missing DEFAULT_LIST_ON

Commit SHA:

6de7239

This is a critical historical fact.

A previous state involving DEFAULT_LIST_ON caused the columns-tab grid
to be missing/broken, and V11.3.1 restored it.

IMPORTANT AGENT RULE:

Do not remove DEFAULT_LIST_ON or similar configuration merely because it
appears redundant.

The Git history demonstrates that configuration related to default list
behavior has previously been important for restoring functionality.

---

# 14. DEVELOPMENT PHASE — V11.4

Commit:

v11.4.0 real field order, row/stack layout, form toggle, all selects in additions

Commit SHA:

542e363

Verified themes:

- Real field order
- Row/stack layout
- Form toggle
- Select fields in additions

This further established the custom field layout system.

---

# 15. DEVELOPMENT PHASE — V11.4.1

Commit:

v11.4.1 dedupe order item fields, product edit, real row/stack and fonts

Commit SHA:

6b97475

Verified themes:

- Deduplication of order item fields
- Product editing
- Real row/stack behavior
- Fonts

The order/product form system was being actively refined.

---

# 16. DEVELOPMENT PHASE — V11.5

Commit:

v11.5.0 split fonts, compact tabs, sticky headers, required star, boxes, no item-box dupes

Commit SHA:

6172abd

Verified themes:

- Split fonts
- Compact tabs
- Sticky headers
- Required field star
- Boxes
- Prevention of duplicate item boxes

The UI became increasingly customized around CRM-specific workflows.

---

# 17. DEVELOPMENT PHASE — V11.5.1

Commit:

v11.5.1 restore main tabs after crm-app.js syntax break

Commit SHA:

f56cb1a

CRITICAL HISTORICAL FACT:

crm-app.js experienced a syntax break during development, and the main tabs
had to be restored.

This proves that crm-app.js is a sensitive/high-impact file.

AGENT RULE:

Before modifying crm-app.js:

1. Inspect current syntax.
2. Inspect dependencies.
3. Inspect all feature files.
4. Test main navigation.
5. Check browser console.
6. Check form/list initialization.

Never rewrite crm-app.js casually.

---

# 18. DEVELOPMENT PHASE — V11.6

Commit:

v11.6.0 fields stay on main tab, box edit, widgets, admin tabs

Commit SHA:

d1955d4

Verified themes:

- Fields staying on main tab
- Box editing
- Widgets
- Admin tabs

The relationship between main tabs, boxes, widgets, and admin configuration
became an important part of the UI architecture.

---

# 19. DEVELOPMENT PHASE — V11.7

Commit:

v11.7.0 boxes with items, tab order on main nav, TENIN logo

Commit SHA:

bc7c447

Additional commits with the same release theme also exist.

Verified themes:

- Boxes with items
- Main navigation tab order
- TENIN logo

The repeated commits indicate iterative development/testing of this area.

Do not assume repeated commits mean the feature is disposable.

---

# 20. CLEANUP COMMIT

Commit:

chore: remove leftover extra files not in current version

Commit SHA:

291ab02

This proves that repository cleanup has occurred historically.

IMPORTANT:

Do not interpret every old-looking file as disposable.

Before deleting a file:

1. Search repository references.
2. Check Git history.
3. Check runtime references.
4. Check deployment references.
5. Verify whether it is intentionally retained.

---

# 21. DEVELOPMENT PHASE — V11.8

Commit:

v11.8.0 one widget per click + manual tab designer

Commit SHA:

3125f0c

Verified themes:

- One widget per click
- Manual tab designer

This is a major architectural milestone.

The project moved further toward a configurable UI/design system.

---

# 22. LOGOUT / NOTIFICATION / HEADER ITERATIONS

Multiple commits exist with the message:

Fix logout button, notification bell sound and update teal header

These commits occurred during the V11 development period.

The repeated commits show iterative debugging/refinement.

Do not assume that repeated commits represent independent features.

They may represent successive attempts at the same behavior.

---

# 23. DEVELOPMENT PHASE — V11.12

Commit:

v11.12.0 searchable selects, geo city after province, shared pharmacy names,
real freeze header, lock manual designer

Commit SHAs include:

db4eba2
358964e

Verified themes:

- Searchable selects
- City selection after province
- Shared pharmacy names
- Real freeze header
- Manual designer lock

This is another major milestone in the form/designer subsystem.

---

# 24. DEVELOPMENT PHASE — V11.13

Commit:

v11.13.0 under-row layout, field width in edit form, edit scroll restore,
delete without hiding siblings, FA labels, required star,
order pharmacy match, one-line align, locked manual design, Excel-related behavior

Commit SHA:

b90f5c6

Verified themes:

- Under-row layout
- Field width in edit form
- Edit scroll restoration
- Delete behavior without hiding siblings
- Persian/FA labels
- Required star
- Order/pharmacy matching
- One-line alignment
- Locked manual design
- Excel-related behavior

This release contains several changes that directly affect real-world
data-entry workflows.

---

# 25. DEVELOPMENT PHASE — V11.14

Commit:

v11.14.0: ستاره چسبیده، فونت جدا، ترتیب فرم/لیست، ارتفاع واقعی،
کادر/کلید، طراح دستی، کپی انتخابی

Commit SHA:

84a8c93

A subsequent commit with the same release theme is:

324c9ad

Verified themes include:

- Attached/connected required star behavior
- Separate fonts
- Form/list ordering
- Real height behavior
- Box/key behavior
- Manual designer
- Selective copy

The later V11.14 commit also added:

AI_PROJECT_CONTEXT.md

Therefore the current repository explicitly contains a machine-readable
project context intended to preserve development knowledge.

---

# 26. AI PROJECT CONTEXT DECISION

Commit:

324c9ad

The repository now contains:

AI_PROJECT_CONTEXT.md

This was created specifically to preserve project knowledge for future
AI-assisted development.

The document states that the project has evolved through multiple versions
and architectural layers and that historical reasoning is not yet fully
recovered.

This means future agents must NOT assume that Git source code alone explains
the reason behind every implementation.

---

# 27. FORM/LIST DESIGNER — HISTORICAL DEVELOPMENT CHAIN

The verified development chain is:

V11.1
    |
    +-- columns picker
    +-- field order
    |
V11.2
    |
    +-- tab fields
    +-- real form edit/delete
    |
V11.3
    |
    +-- row order
    +-- field movement
    +-- field size
    +-- form/list visibility
    |
V11.3.1
    |
    +-- DEFAULT_LIST_ON restoration
    |
V11.4
    |
    +-- real field order
    +-- row/stack
    +-- form toggle
    |
V11.4.1
    |
    +-- deduplication
    +-- product edit
    |
V11.5
    |
    +-- fonts
    +-- compact tabs
    +-- sticky headers
    +-- required star
    +-- boxes
    |
V11.5.1
    |
    +-- crm-app.js syntax recovery
    |
V11.6
    |
    +-- boxes
    +-- widgets
    +-- admin tabs
    |
V11.7
    |
    +-- boxes with items
    +-- main nav order
    |
V11.8
    |
    +-- manual tab designer
    |
V11.12
    |
    +-- searchable selects
    +-- freeze header
    +-- lock manual designer
    |
V11.13
    |
    +-- under-row
    +-- field width
    +-- edit scroll restore
    +-- delete behavior
    +-- required star
    |
V11.14
    |
    +-- form/list order
    +-- real height
    +-- manual designer
    +-- selective copy

CONCLUSION:

The current Form/List/Manual Designer subsystem is the result of a long
iterative development chain.

It must NOT be replaced casually.

---

# 28. VERIFIED SAFETY LESSONS FROM HISTORY

The Git history provides several concrete lessons.

LESSON 1:

crm-app.js can suffer syntax-level breakage that affects main navigation.

LESSON 2:

Removing or changing configuration can break the columns/list system.

LESSON 3:

Form/List behavior has been changed repeatedly across many versions.

LESSON 4:

Manual Designer functionality is deeply integrated into later versions.

LESSON 5:

Cleanup has occurred before, but cleanup must not be performed without
reference analysis.

LESSON 6:

Repeated commits may represent iterative debugging rather than unnecessary
duplication.

LESSON 7:

The project contains historical requirements that are not fully represented
by current source code alone.

---

# 29. WHAT GIT CAN TELL US

Git can reliably tell us:

- What files changed
- When a commit occurred
- Commit message
- Commit sequence
- Which version was being developed
- Some implementation evolution

---

# 30. WHAT GIT CANNOT TELL US

Git alone cannot reliably tell us:

- The exact user request
- The exact original AI prompt
- Why the user wanted a change
- Which alternatives were rejected
- Which UI behavior was considered mandatory
- Which bug originally motivated a change unless documented
- Which hidden business rule was discussed in the lost conversation

Therefore these must remain UNKNOWN until recovered from other evidence.

---

# 31. NO FABRICATION RULE

Future AI agents must never invent historical reasoning.

If the agent does not know why a feature exists:

Say:

"Historical reason not recovered."

Do not say:

"This was designed because..."

unless the repository or recovered conversation proves it.

---

# 32. DECISION CONFIDENCE LEVELS

Use these labels:

[VERIFIED]
Directly supported by Git/source/documentation.

[INFERRED]
Reasonable interpretation supported by multiple verified facts.

[UNKNOWN]
Not currently recoverable.

Example:

[VERIFIED]
V11.8 introduced the manual tab designer.

[INFERRED]
The manual designer became a core UI customization subsystem.

[UNKNOWN]
The original user requirement that caused the manual designer to be built.

---

# 33. FUTURE DECISION LOGGING RULE

Every important future change should add an entry containing:

Date:
Version:
Commit:
Request:
Reason:
Affected subsystem:
Affected files:
Decision:
Alternatives considered:
Risk:
Verification:
Rollback:

If some information is unknown:

Write UNKNOWN.

Never invent missing information.

---

# 34. FUTURE AI DEVELOPMENT RULE

Before modifying an existing subsystem:

1. Read AI_PROJECT_CONTEXT.md
2. Read AI_ARCHITECTURE.md
3. Read AI_RULES.md
4. Read relevant section of AI_DECISION_LOG.md
5. Inspect Git history
6. Inspect current source
7. Identify dependencies
8. Perform READ-ONLY analysis
9. Report findings
10. Wait for approval when required

---

# 35. CURRENT HISTORICAL BASELINE

Current recovered baseline:

V5
  ↓
V6
  ↓
V7
  ↓
V8
  ↓
V9
  ↓
V10
  ↓
V11.0
  ↓
V11.1
  ↓
V11.2
  ↓
V11.3
  ↓
V11.3.1
  ↓
V11.4
  ↓
V11.4.1
  ↓
V11.5
  ↓
V11.5.1
  ↓
V11.6
  ↓
V11.7
  ↓
V11.8
  ↓
V11.12
  ↓
V11.13
  ↓
V11.14
  ↓
V11.15

This is the currently recovered historical development path.

It is NOT claimed to be a complete list of every commit.

---

# 36. CURRENT UNKNOWN HISTORY

The following remain unrecovered:

1. Complete original AI conversation.
2. Complete original prompts.
3. Complete reasoning behind V5.
4. Complete reasoning behind V6's 12 historical prompts.
5. Complete original Ultra-Professional Master Specification.
6. Complete reasoning behind every V9 feature.
7. Complete reasoning behind V10 architecture.
8. Complete reasons for retaining parallel systems.
9. Complete reasons behind every cleanup decision.
10. Complete production incidents that motivated individual fixes.

These must remain UNKNOWN.

---

# 37. FINAL RULE

The repository is the verified implementation history.

AI_PROJECT_CONTEXT.md describes the project context.

AI_ARCHITECTURE.md describes the architecture.

AI_DECISION_LOG.md describes verified historical evolution.

None of these documents should be treated as permission to redesign the
system.

They exist to prevent loss of knowledge and accidental regressions.

---

# 38. V11.15.0 DEVELOPMENT PHASE

Date: 2026-08-16

Source of request: single user message listing 14 numbered change requests,
plus the explicit constraints: do not change the project skeleton, deliver
the complete program files for download, and supply the GitHub update
commands with the new version.

Decision 1 — keep the versioned-file pattern (VERIFIED)
A single new file `public/crm-features-v19.js` was created and loaded last
(after v18) in `index.html`. Surgical edits were made to `crm-app.js`
(order items/totals only), `crm-features-v11.js` (delete semantics, builtin
`allowAddOption`, skip `meta.deleted`), `crm-data.js` (one new
`PERMISSION_GROUPS` group), `index.html` (order-table header/totals markup,
removal of the two additions-tab boxes, version bumps), `sw.js`,
`server.js`, and `package.json`. No existing versioned file was deleted or
renamed.

Decision 2 — request #9 was ambiguous (VERIFIED as ambiguity)
The Persian sentence for item 9 contains a typo that makes the literal
meaning unclear. Implemented interpretation: an edit ✏️ button was added
NEXT TO the existing delete 🗑️ button on each order-item row, opening the
matching catalog product for editing. This interpretation is INFERRED and
must be confirmed or corrected by the user.

Decision 3 — real list ordering (VERIFIED in code)
List column ordering previously existed only as stored numbers (the v18
wrapper sorted a discarded copy — dead code). v19 now reorders actual
rendered table cells against a slot map that mirrors each list renderer's
column structure, guarded by a cell-count check; if a renderer's structure
changes the reorder silently skips instead of corrupting rows.

Decision 4 — backup target storage (VERIFIED design, PENDING browser test)
The File System Access API directory/file handle cannot be kept in
localStorage; it is persisted in IndexedDB and re-granted with
`queryPermission`/`requestPermission` on the backup page. Saving directly
into a user-chosen folder silently is only possible in Chromium-based
browsers over a secure context; other browsers get a "save as" picker or a
regular download fallback. This is a platform limitation, not a code
choice.

Decision 5 — fake connectivity test retired (VERIFIED)
`testServerConnectivity` in `crm-app.js` was a hardcoded 700 ms setTimeout
that always reported success. The troubleshooting button now runs the
granular diagnostic suite instead. The original function body was left in
place (overridden at runtime by v19) to keep `crm-app.js` edits minimal.

Decision 6 — permissions rule (VERIFIED, user-mandated)
Item 14 was recorded as a permanent rule in AI_RULES.md (#62). The new
permission group "ابزارهای مدیریت (نسخه ۱۱.۱۵)" was appended to
`PERMISSION_GROUPS`; existing users keep working because
`getDefaultPermissionsObject(true)` covers new keys and
`migratePermissions` backfills them.

UNKNOWN on purpose:

1. Whether the user's hosted production (Render) currently serves the state
   the user edits locally; deployment was not touched in this phase.
2. Whether item 9's interpretation matches the user's intent.
3. Long-term interaction between the v19 cell-reorder engine and any future
   list renderer that changes its column structure.

Verification status: `node --check` passes for every JS file; an HTTP smoke
test of `server.js` served index.html (with the v19 tag) and reported
version 11.15.0 on `/api/health` (VERIFIED). All 14 items still require
in-browser confirmation by the user (PENDING USER VERIFICATION).

---

---

# 39. CHAT.ARENA MEMORY FILE DECISION

Date: 2026-08-16

The user requested a single permanent handoff file named `chat.arena` that
must always contain: the full project summary, architecture, the complete
ordered user/AI chat, all permanent rules, and the complete source of every
text file — so that a fresh AI session can continue the project with zero
verbal explanation.

Decision:
chat.arena is created at the repository root and treated as a required
project artifact. AI_RULES.md #63 makes its continuous update and inclusion
in every delivered ZIP mandatory.

Reason:
the user explicitly wants immunity against chat loss / context breakage.

---

# 40. V11.15.1 HOTFIX — HARDCODED REQUIRED-FIELD CHECKS REMOVED

Date: 2026-08-16

User report: the star problem was not solved by v11.15.0; with only
pharmacyName starred, saving a pharmacy still raised
«لطفاً نام، استان، شهر، منطقه و آدرس/لوکیشن داروخانه را کامل کنید.»

Root cause (VERIFIED from source): 9 hardcoded `if (!field...) alert(...)`
blocks in the entity save paths, independent of the star system:
3 in the active v9 handlers (`savePharmacyV9`, `saveDoctorV9`,
`saveOrderV9` in crm-features-v9.js) and 6 in the two duplicated code
generations of crm-app.js.

Fix (VERIFIED): all 9 blocks replaced by a call to
`window.validateRequiredFields(tabId)` — the star-aware validator that only
blocks on admin-starred fields and skips hidden/deleted fields. The
"at least one order item" check was kept as a business rule (not a field).
Version bumped to 11.15.1 (package.json, server.js health/log, sw.js cache,
index.html ?v= params). node --check green; /api/health reports 11.15.1.

PENDING USER VERIFICATION in the browser: with only pharmacyName starred,
saving a pharmacy with empty province/city/district/address must now succeed
without any forced-field warning.

---

# 41. AUTOMATIC DELIVERY ZIP RULE

Date: 2026-08-16

User feedback: the ZIP they downloaded was still v11.15.0 (server logs
confirmed those downloads happened before the v11.15.1 build existed), and
they declared a new PERMANENT rule: whenever a user request is completed, a
fresh download ZIP must automatically appear next to the page.

Decision:
Recorded as AI_RULES.md #64. Delivery checklist per completed request:
rebuild ZIP → point the download preview at the new file (restart it) →
present the ZIP → verify the embedded package.json version and state the
proof in the reply.

---

# 42. V11.15.2 — DUPLICATE-SAVE WARNING BECOMES A REAL CHOICE

Date: 2026-08-16

User request: the duplicate pharmacy warning ("هشدار: داروخانه‌ای با این نام
یا تلفن قبلاً ثبت شده؛ با این حال ذخیره می‌شود.") showed only OK and always
saved. Wanted: yes/no choice; خیر must cancel the save.

Change (VERIFIED): all four duplicate-warning sites (pharmacy + doctor in
the active v9 save handlers, and the two duplicated generations in
crm-app.js) converted from one-way `alert` to `window.confirm`; cancelling
returns before the record is pushed. Version bumped to 11.15.2.

Note (stated to user honestly): the two button captions come from the
browser (تأیید/انصراف in Persian Windows); the dialog text itself spells
out which button saves and which cancels.

---

# 43. OFFICIAL_FILELIST WHITELIST REPAIR + DURABLE CHAT.ARENA GENERATOR

Date: 2026-08-16

Findings (VERIFIED):
1. OFFICIAL_FILELIST.txt — the whitelist consumed by the user's
   CLEAN_EXTRA_FILES.bat (scripts/clean-extra-files.ps1 deletes any file not
   listed) — was missing: chat.arena, public/crm-features-v17.js,
   public/crm-features-v18.js, public/crm-features-v19.js, all AI_*.md
   memory files, and ARENA_HANDOFF_PROMPT.md. Running the cleanup would
   have deleted them from the user's machine.
2. The Arena sandbox reset wiped workspace-root helpers (the old chat.arena
   generator, the download server, the zips) — only the git repo persisted.

Decisions:
- All missing files were added to OFFICIAL_FILELIST.txt (now 234 entries).
- The chat.arena generator was recreated INSIDE the repo as
  `update_chat_arena.py` (self-locating via its own path) so it ships in the
  ZIP and survives sandbox resets; rules #63/#64 remain in force — the
  file is regenerated via this script after every chat/version.
- chat.arena rule #8 added (permanent): every new project file must be
  added to OFFICIAL_FILELIST.txt immediately.

---

# 44. V11.15.3 — ZERO-DEPENDENCY RUNTIME (node_modules FULLY REMOVABLE)

Date: 2026-08-16

User request: node_modules must never enter GitHub/GitLab and, if possible,
should not need to be installed at all — plus a delete command for it.

Verification (VERIFIED):
- `server.js` requires only Node built-ins: http, fs, path, zlib, crypto.
- Every `scripts/*.mjs` imports only Node built-ins (fs/path/url/child_process).
- `git ls-files` + history: node_modules was NEVER tracked in git.
- `.gitignore` already had `/node_modules`; extended to any-depth
  `node_modules/`.

Decision: the declared `express`/`cors` dependencies in package.json were
dead weight from the dormant Next.js skeleton era. Removed them (v11.15.3)
and regenerated `package-lock.json` dependency-free (292 bytes, 0 packages,
npm audit: 0 vulnerabilities). `npm install` is now a no-op on Render
(`npm install --include=dev && npm run build` still succeeds). User delete
command: `rmdir /s /q node_modules` (Windows) / `rm -rf node_modules` (Linux/Mac).

---

# 45. GIT SECRETS AUDIT + HARDENED .gitignore (v11.15.3)

Date: 2026-08-16

User request: guarantee `.env` (tokens/passwords) never enters Git, and
delete it from GitHub if already there.

Audit result (VERIFIED): no real `.env` ever existed in git history. The
only tracked match is the template `.env.ndcohub.example`; it contained a
sample line `ADMIN_PASSWORD=admin1234` which was sanitized to `--------`.

Changes: `.gitignore` now blocks `.env`, `.env.*`, `*.env` with explicit
re-allow `!.env*.example`, plus `server-db.json`, `*.zip`, `.arena/`,
any-depth `node_modules/`. Rule recorded as AI_RULES #65 with a rotation
mandate if a real secret is ever leaked to git.

---

# 46. DUAL-REMOTE ONE-COMMAND SYNC + CROSS-SYSTEM FILES (v11.15.3)

Date: 2026-08-16

User request: every local change must update GitHub AND GitLab with ONE
command; files must work on any system (user alternates between two PCs
and moves the project folder between them).

Changes:
- `SYNC_ALL.bat` (Windows) and `sync_all.sh` (Linux/Mac): pull origin →
  pull gitlab (if remote exists) → `git add -A` → commit (message arg or
  timestamp) → push origin → push gitlab. Works immediately for GitHub
  only; GitLab activates after the one-time `git remote add gitlab ...`
  (steps in `RAHNAMA_GITLAB.txt`).
- `.gitattributes` added: `* text=auto`, `.bat/.cmd/.ps1`=CRLF,
  `.sh/.py/.mjs`=LF, images/fonts/zips binary — line endings can no longer
  break scripts when hopping between Windows and Linux.
- `.gitlab-ci.yml` build stage: removed the dormant-Next steps
  (`npx next typegen`, `npx tsc --noEmit`) so GitLab CI stays green like the
  Render echo-build. Mirror stage (GitLab→GitHub) left intact (optional).
- OFFICIAL_FILELIST.txt: added `KEEP_ONLY_GITHUB.bat` (was missing —
  cleanup would have deleted it) plus the 4 new files (239 entries).

---

# 47. PROJECT KNOWLEDGE GRAPH (PROJECT_GRAPH.md + update_project_graph.py)

Date: 2026-08-16

User request: stop re-reading the whole codebase every turn (token waste);
build ONE file that is the project's knowledge graph (all files, "classes"
/functions, and their relationships — e.g. what relates to the API service)
and keep it updated as the AI's first-stop reference.

Decision (VERIFIED): `update_project_graph.py` statically parses server.js,
scripts/*.mjs and all public/*.js and emits `PROJECT_GRAPH.md`: script load
chain (17 scripts), per-file cards (role/size/functions/window names), the
window override graph (which layer overrides which), the API consumer map,
browser-storage key map, tab↔file map and duplicated-function hotspots.
Output deterministic; rule #66 makes it regenerate before every chat.arena
build. First build: 26 files, 131 window names, 23 tabs, 36 KB.

---

# 48. V11.16.0 — crm-features-v20.js MEGA-LAYER

Date: 2026-08-16

New last-layer file `public/crm-features-v20.js` (no skeleton changes; loads
after v19 so it wins all overrides):

1. `window.state` getter (defineProperty) — the v19 diagnostics row
   «شی state در دسترس نیست» was because crm-app.js declares `state` with a
   lexical binding, invisible as window.state. Fixed; plus /api/state now
   reports a neutral OK line and the stale cloud-servers blurb in
   index.html was replaced with real guidance.
2. `window.v20DupGate(kind)` — exact-duplicate records (all normalized
   fields equal, incl. case of ANOTHER user having entered them) are HARD
   BLOCKED with "edit-only" message; near duplicates (name or phone) keep
   the 11.15.2 confirm dialog. Wired into all 4 save paths (v9 pharmacy/
   doctor + 2 duplicate generations in crm-app.js per rule #1/#62 spirit).
3. Additions-tab combo manager: per-tab selector, every combo field of the
   tab with Persian label, its options stacked UNDER the field, per-option
   ✏️/🗑️, per-field instant search, per-field add box, and live refresh
   (MutationObserver + saveState wrap). Renames/removals persist via
   state.v20Renames / state.v20HiddenOptions / state.selectExtraOptions.
4. Grey-chain engine: dependent fields disabled+grey until parent filled
   (defaults: province→city→district in pharmacy/doctor/order); master
   toggle + per-field parent selector in the combo manager
   (state.v20GreyMap, settings.v20GreyOn).
5. Order form lock: all fields grey/disabled except pharmacy name until an
   existing pharmacy is selected and auto-filled ("جایگذاری خودکار");
   afterwards descriptor fields stay grey and ONLY the product section is
   active (settings.v20OrderLock, default ON).
6. Pharmacy-name instant add ⇒ auto-save (delegated click on the ➕ add
   button inside tab-pharmacies clicks btnSavePharmacy).
7. Mirror: fields added/removed in pharmacies tab auto-add/remove in orders
   (state.customFields clone with `ordm-` prefix + deleteCustomField wrap).
8. Product-box field insertion fix: stored customFields.products are now
   rendered into the product form grid with real width/order applied.
9. List columns: post-render reorder wrapper enforcing ردیف=col#1,
   rep-name=col#2 and listOrder for mapped columns (2+ matches required).
10. Number spinners removed from order-item qty inputs (CSS).
11. "🔑 تغییر رمز" button fixed at the top of every page; writes
    CRM_USERS_AUTH + state.users so the next login uses the new password.
12. Role presets (نماینده علمی / کارشناس فروش / سرپرست) in the users tab —
    one click applies a ready-made permission bundle (admin user excluded).
    New PERMISSION_GROUPS block «ابزارهای مدیریت (نسخه ۱۱.۱۶)» in
    crm-data.js (rule #62 satisfied).

All syntax-checked (node --check) and server smoke-tested (11.16.0).
Browser confirmation by the user is pending.

---

# 49. GITHUB REMOTE HISTORY REPLACED — "پروژه اولیه" SINGLE COMMIT

Date: 2026-08-16

User report: GitHub did NOT show the updated files (still old program).

Diagnosis (VERIFIED via fetch): origin/main had been replaced by ONE manual
commit `c0abb06 «پروژه اولیه»` containing the v11.15.3 snapshot (has
SYNC_ALL.bat / chat.arena / crm-features-v19.js / update_chat_arena.py;
NO crm-features-v20.js / PROJECT_GRAPH.md). The old history (921f60d etc.)
is gone from remote, so the user's normal pushes were rejected
(unrelated/diverged histories).

Fix delivered: `PUSH_FRESH_GITHUB.bat` — commits local files, fetches,
merges with `--allow-unrelated-histories -X ours` (his files always win),
then pushes and prints the remote tip as proof. After this one-time repair,
SYNC_ALL.bat works normally again.

GitLab without token (user: token page is disabled): SSH-key method was
documented in RAHNAMA_GITLAB.txt (ssh-keygen → add public key →
remote set-url gitlab git@gitlab.com:...). GitLab support stays in the
code (SYNC_ALL auto-detects the gitlab remote and skips gracefully).

---

# 50. V11.16.2 — USER-REPORTED FIX PACK

Date: 2026-08-16

User findings (browser) and fixes in crm-features-v20.js:
1. Combo-manager cards now render side-by-side in a responsive grid
   (`.v20-cards`, auto-fill ≥330px) — not all stacked.
2. English field names: faLabel v2 falls back to placeholder text and a
   built-in Persian dictionary (V20_FA_IDS). Jalali year/month selects are
   excluded from the combos manager (isDatePartField), so «سال/ماه» no
   longer clutter the pharmacies card area and «نوع داروخانه» is a normal
   card like other combos.
3. Grey uniformity: new `setFieldGrey()` greys the whole form-group AND
   disables the visible `.crm-combo-input` (pointer-events:none on
   `.crm-combo.v20-locked`) — kills the "half grey / half white" state and
   stops grey-but-selectable combos in orders. Scroll position is
   preserved around every engine run (fixes the field-jump-after-province
   complaint).
4. Orders: product section (#orderItemsContainer / catalog bar / totals)
   is now ALWAYS active; descriptor fields grey; pharmacy field ORDER
   changes mirror into orders (`mirrorPharmacyOrderToOrders`, alias
   pharmacy Name ↔ order PharmacyName, hooked on applyFullFormLayout).
5. Change-password FAB docks inside the header next to #btnLogoutSystem
   (inline-block), no longer overlapping the logout button.
6. Duplicate false-positive on instant-add: gate now excludes the record
   being edited, and v20SigOf/_v20AutoSaveSig suppression turns the
   re-save of a just-auto-saved record into a friendly notice without
   creating a duplicate row.

Syntax-checked; server smoke 11.16.2 OK. Browser verification pending.

## تصمیم ۵۱ — نسخه ۱۱.۱۷.۰: تثبیت شناسه‌ها و موتور ویزیت/رصد (2026-08-17)
- مرتب‌سازی خودکار DOM داروخانه→سفارش غیرفعال شد تا جای فیلدها بین نسخه‌ها ثابت بماند.
- قابلیت‌های بزرگ فقط در آخرین لایه v20 افزوده شدند؛ مسیر فعال لیست‌های v9 فقط برای «جدیدترین بالا» اصلاح شد.
- جلسه GPS در state ذخیره و پس از پایان با unshift در repRoutes و visitTracks ماندگار می‌شود.
- workflow متناسب با معماری واقعی صفر-وابستگی Node اصلاح شد؛ Next خفته دیگر در CI اجرا نمی‌شود.

## تصمیم ۵۲ — نسخه ۱۱.۱۷.۱: صفر واقعی تعداد و رابط مقیاس‌پذیر (2026-08-17)
- مسیر فعال v9 از `parseInt(...) || 1` به صفر+فیلتر qty<=0 تغییر کرد و هر دو نسل crm-app نیز quantityValidated می‌نویسند.
- فهرست اشتراک از ثابت به پویا بر اساس ستون‌های هسته، extraListColumns و customFields قابل نمایش تبدیل شد.
- برای مقیاس ۱۰هزار نام، رندر کامل ممنوع و فقط جستجوی حداقل دو حرف/۵۰ نتیجه مجاز شد.
- پنل قدیمی افزودن‌ها مخفی و v20 تمام عرض شد؛ فیلتر تعلق شناسه مانع نشت فیلد داروخانه به پزشک است.

## تصمیم ۵۳ — نسخه ۱۱.۱۸.۰: اسنپ سازمانی امن و بدون دورزدن CAPTCHA (2026-08-17)
- اعتبارنامه افشاشده عمداً در هیچ فایل ثبت نشد و کاربر ملزم به تغییر رمز شد.
- به‌جای ربات CAPTCHA، ورود دستی مدیر + ورود دو فایل و dedupe محلی پیاده شد؛ خودکارسازی کامل فقط با API رسمی آینده مجاز است.
- XLSX با ZIP/XML بومی مرورگر و CSV/XLS متنی بدون dependency خارجی خوانده می‌شود.
- گزارش‌های اسنپ در state.snappCorporate، با فیلتر سال/ماه/بازه و تجمیع نماینده ذخیره می‌شوند.
- موقعیت همه نمایندگان و reverse geocode متنی در v20 اضافه شد.

## تصمیم ۵۴ — نسخه ۱۱.۱۹.۰: آرشیو حذف‌ناپذیر و ترتیب پیام (2026-08-17)
- داده سفر و افزایش موجودی با prepend+dedupe در state.snappCorporate ماندگار است؛ کلید حذف و دسترسی حذف برداشته شد.
- همه backupها JSON.stringify(state) هستند، پس آرشیو اسنپ خودکار داخل پشتیبان قرار دارد.
- ترتیب متن ارسالی در settings.v20ShareOrder و انتخاب در v20ShareFields ذخیره می‌شود.
- ساختار فایل واقعی مرورگر کاربر از سرور قابل دریافت نبود (`/api/state` خالی)؛ تشخیص پویا سرستون و مهاجرت header اضافه شد.
- تارگت مالی در v20 از قیمت جاری کالا مشتق و جمع کل/نماینده محاسبه می‌شود.

## تصمیم ۵۵ — نسخه ۱۱.۲۰.۰: schema صریح اسنپ و ایمیل امن (2026-08-17)
- schema سفر دقیقاً ۹ سرستون اعلامی و schema شارژ «تاریخ و ساعت/بستانکار» است؛ خروجی نمایش تاریخ/ساعت را جدا می‌کند.
- کاربران غیرمدیر منبع فیلتر نماینده‌اند و normPerson القاب آقا/خانم را حذف می‌کند.
- ایمیل backup از سرور و Resend ارسال می‌شود؛ هیچ API key در repo نیست و نبود تنظیم با 503 شفاف اعلام می‌شود.
- جزئیات سفارش با buildLockedShare یکسان شد و لیست v9 cleanOrderItemsV9 را مصرف می‌کند.
## تصمیم ۵۶ — نسخه ۱۱.۲۰.۱: بلوک ثابت سفارش و فیلترهای اختیاری (2026-08-17)
- اقلام و دو جمع مالی از تنظیم فیلدهای مدیر جدا و همیشه با قالب ثابت ساخته می‌شوند.
- تاریخ‌های اسنپ دیگر auto-fill نیستند تا year/month مستقل عمل کند؛ topup فقط amount>0 است.
- formatter دیداری اعداد، تاریخ/سال/تلفن/مختصات را مستثنی می‌کند.
## تصمیم ۵۷ — نسخه ۱۱.۲۰.۲: داده و چیدمان هرگز با نمونه جایگزین نشود (2026-08-18)
- loadState از current/rolling/latest/pre-11.11 غنی‌ترین وضعیت را انتخاب می‌کند.
- missing keys در state واقعی با empty تکمیل می‌شوند نه DEFAULT sample.
- saveState قبل از نوشتن rolling backup می‌گیرد؛ v20 وضعیت را debounced به server می‌فرستد و remote جدیدتر را بازیابی می‌کند.
## تصمیم ۵۸ — نسخه ۱۱.۲۰.۳: Union recovery به‌جای winner-takes-all (2026-08-18)
- همه snapshotها برای رکوردها union می‌شوند؛ تنظیمات layout کامل‌تر برنده است.
- remote state با local merge می‌شود و هرگز جایگزینی کامل ندارد.
- personMatch القاب فارسی و تطبیق جزئی نام اسنپ را پوشش می‌دهد.
## تصمیم ۵۹ — نسخه ۱۱.۲۰.۴: Mobile-first و structure manager-only (2026-08-18)
- زیر 768px nav افقی حذف و همه عرض/گریدها داخل viewport محدود می‌شوند.
- temporal mode اسنپ year/month/range انحصاری است و ماه به سال وابسته.
- historical union یک‌بار با marker انجام می‌شود تا حذف بعدی مدیر resurrect نشود؛ current layout برنده است.
## تصمیم ۶۰ — نسخه ۱۱.۲۰.۵: rebase تنظیمات روی snapshot 11.20.3 (2026-08-18)
- آخرین snapshot بدون marker مهاجرت 11.20.4 منبع settings/layout است؛ record data آن نیز یک‌بار re-merge می‌شود.
- پس از marker، هیچ backup/remote قدیمی ساختار مدیر را resurrect نمی‌کند.
- mobile/filter/date features حفظ شدند ولی روی layout بازگردانده‌شده اجرا می‌شوند.
## تصمیم ۶۱ — نسخه ۱۱.۲۱.۰: tests gate deployment + distributor data mart (2026-08-18)
- node:test zero-dependency suite هم unit preservation و هم HTTP app-entry/API/assets را پوشش می‌دهد؛ CI قبل build اجرا می‌کند.
- login خودکار cross-origin پخش قابل‌اعتماد نیست؛ URL configurable + manual imports راه امن است. password فقط sessionStorage است.
- pharmacy imports append+dedupe و inventory replace است؛ گزارش all/4 distributors و multi-sheet XML XLS ساخته می‌شود.
## تصمیم ۶۲ — نسخه ۱۱.۲۱.۱: database tab + Daya explicit schema (2026-08-19)
- raw database/file viewers از sales به tab-distributor-database منتقل شدند.
- Daya explicit indices اعمال و سایر پخش‌ها header-regex باقی ماند تا sample برسد.
- Product CRUD در final v20 capture handler تثبیت شد.
- Snapp archives در snappStore به‌صورت پایدار dedupe می‌شوند تا جمع چندبرابر نشود.
## تصمیم ۶۳ — نسخه ۱۱.۲۱.۲: bulk Excel in IndexedDB + code-first matching (2026-08-19)
- علت حذف پس از refresh، quota localStorage تشخیص داده شد؛ bulk rows/imports به IDB و metadata به localStorage رفت.
- Daya matching از name به code column 16 و productCode formula منتقل شد.
- product delete cascade targets/orders/draft و report canonical filtering دارد.
## تصمیم ۶۴ — نسخه ۱۱.۲۱.۳: current state تنها source of truth (2026-08-19)
- علت بازگشت داده قدیمی، auto merge/recovery بود؛ همه مسیرهای خودکار حذف شدند.
- remote فقط POST است؛ backup فقط manual. empty array deletion معتبر است.
- runtime mergeStateWithoutLoss حذف و tests بر ضد reintroduction تغییر کردند.
## تصمیم ۶۵ — نسخه ۱۱.۲۱.۴: explicit import buttons + last physical row date (2026-08-19)
- Snapp file labels با buttons و robust onchange جایگزین شدند.
- distributor last date دیگر max-sort نیست؛ آخرین سطر فیزیکی معتبر برنده است.
- product codes/date raw values از global number grouping مستثنی‌اند.
## تصمیم ۶۶ — نسخه ۱۱.۲۱.۵: runtime DOM test found early-init race (2026-08-19)
- jsdom نشان داد v20 declarations load ولی init features قبل از state آماده bind نمی‌شدند؛ syntax tests کافی نبودند.
- critical import/product handlers synchronous و reliableFeatureBoot روی load/tab click شد.
- raw Excel viewers editable شدند و save به master rows + IndexedDB می‌نویسد.
## تصمیم ۶۷ — نسخه ۱۱.۲۱.۶: legacy row migration fixes reported runtime crash (2026-08-20)
- console trace proved non-array historical rows stopped reliableFeatureBoot. normalizeStoredRow now fronts signatures/header/date/render.
- DOM test seeded object/cells legacy rows and verified imports/actions with zero errors.
- DB viewers now edit and persist master rows, not only presentation.
## تصمیم ۶۸ — نسخه ۱۱.۲۱.۷: distributor dates are slash-only, never calendar-converted (2026-08-20)
- normSnappDate برای پخش ممنوع؛ slashOnlyPersianDate فقط compact Jalali 8-digit را format می‌کند.
- filter grid desktop flex nowrap است تا saved grid styles نتوانند زیرهم کنند.
## تصمیم ۶۹ — نسخه ۱۱.۲۱.۸: Daya exact quantities and global unique sets (2026-08-20)
- Daya ignores file rial columns; all monetary metrics derive quantity × master prices.
- customer/invoice totals use global set union, not sum of product row counts.
- DOM test proved layout engine had moved filters to cfHost; restoreFixedFilterGrids moves them back.
## تصمیم ۷۰ — نسخه ۱۱.۲۱.۹: align inventory headers; current metadata quota cleanup (2026-08-20)
- Daya inventory headers only shift, rows never shift.
- Obsolete automatic local backups removed/no-op because they consumed quota and caused current changes to vanish after refresh.
- Report ordering is master state.products; workbook follows same rows.
## تصمیم ۷۱ — نسخه ۱۱.۲۲.۰: real Daya inventory schema exact headers (2026-08-20)
- broad /کالا/ regex matched «کالای در راه»؛ exact نام کالا/کد کالا/موجودی now wins.
- real sample 1112002 quantity6 is a regression fixture.
## تصمیم ۷۲ — نسخه ۱۱.۲۲.۱: Latin digits, sticky tables, safe location, effective list order (2026-08-20)
- final DOM formatter Latinizes every digit; grouping is en-US except code/date/phone.
- Excel percent cells are strings with %, number cells have #,##0 and all cells borders.
- list reorder bug was getUnifiedFieldList(key) instead of paneId plus strict matched>=2.
- address fields textarea+guard; GPS fake fallback removed.
## تصمیم ۷۳ — نسخه ۱۱.۲۲.۲: Persian address order + DOM order lock + Shafaarad schema (2026-08-20)
- Nominatim display_name reversed output no longer overrides ordered Persian address; postcode explicitly labeled.
- DOM core form group order has independent local lock captured before unload/manager edits and restored after all layout engines.
- Shafaarad inventory computed column10 is derived every import/hydrate and immutable from source replacement.
## تصمیم ۷۴ — نسخه ۱۱.۲۲.۳: Shafa code-first; gray/black headers; live layout/list guards (2026-08-20)
- Shafa 1005/1006 database suffixes are intentionally swapped and unit-tested.
- Program headers gray/black; workbook totals red and percentages strings.
- Mutation observers protect fixed filters and list order after old render/layout layers.
- GPS uses best watch accuracy; postcode removed.
## تصمیم ۷۵ — نسخه ۱۱.۲۳.۰: user-data isolation, permission templates, atomic order (2026-08-20)
- Runtime state file is user-data.json, gitignored and migrated from legacy server-db.
- User edit now update-not-duplicate and syncs CRM_USERS_AUTH.
- Permission templates are saved from real checkbox tree; create role applies template.
- Order inputs intercepted in capture phase; atomic reorder avoids destructive layout rebuild.

# END OF AI DECISION LOG
## تصمیم ۷۶ — نسخه ۱۱.۲۴.۰: سبک‌سازی محدود، اعمال لحظه‌ای و قانون بصری سراسری (2026-08-21)
- MutationObserver اعداد فقط addedNodes را پردازش می‌کند و دیگر کل body را با هر تغییر نمی‌خواند.
- refresh پس از save فقط وقتی ذخیره ناشی از اقدام اخیر کاربر است و فقط نمای فعال را render می‌کند؛ GPS رندر سراسری ایجاد نمی‌کند.
- spacerهای دو موتور freeze پنهان شدند؛ همه headerها sky-blue/black هستند.
- Default SpreadsheetML بدون border است و فقط style سلول‌های واقعی border دارد.
- GPS ثابت: high accuracy، دو نمونه، هدف <=10m، بهترین نقطه تا 30s؛ آدرس Iran-first بدون postcode.
## تصمیم ۷۷ — نسخه ۱۱.۲۴.۱: نگاشت اصلاحی شفاآراد و نسخه پویا (2026-08-21)
- Shafa exact map is now 1001→1391911001, 1002→1391911002, 1003→1391911003, 1004→1391911004, 1005→1391911006, 1006→1391911005, 1007→1391902006.
- ensureProductCodes overwrites stale shafaDbCode values in current catalog without touching other user data.
- Daya/Shafa unmatched or «نامشخص» rows are omitted, never invented as a report product.
- Header badge derives version from active v20 script query and is updated on every render.
## تصمیم ۷۸ — نسخه ۱۱.۲۵.۰: تطبیق سفارش با فاکتور پخش (2026-08-21)
- Invoice groups are pre-indexed by exact Jalali day and scanned only for orderDay-3..orderDay+3.
- Pharmacy name matching accepts meaningful shared/contained tokens while province, city and district must also resolve from columns or row text.
- Only matched invoices appear; unmatched orders are intentionally absent.
- Invoice details aggregate rows by canonical master product and compare ordered/invoiced quantity and gift with signed differences.
- Base matches are cached per tab entry so live text filtering does not rescan IndexedDB-sized rows.
## تصمیم ۷۹ — نسخه ۱۱.۲۶.۰: Option registry سراسری، قفل همه تب‌ها و PWA خودکنترل (2026-08-21)
- `settings.globalFieldOptions` is the single option registry keyed by semantic label; hidden values prevent deleted static options from returning after rerender.
- Add/rename/delete propagates to all matching DOM selects/datalists and all matching customFields.
- New same-label fields are hydrated from the registry; pharmacy/users/year/month can seed initial canonical options.
- Layout lock enumerates every tab `.form-grid`, restores each independently, and observes delayed legacy form-group insertions.
- Invoice tab visibility now clears stale inline `display:none`; missing new permission inherits prior dist-sales access.
- PWA registration is cache-bypassed/versioned and activation is automatic, with no manual-refresh diagnostic loop.
## تصمیم ۸۰ — نسخه ۱۱.۲۷.۰: مهار startup layout، permission tabs واقعی و CRUD نهایی کاربر (2026-08-21)
- Legacy `applyFullFormLayout` is blocked unless an 800ms manager-intent gate is armed from columns/manual-design controls; wrapper binds synchronously before DOMContent startup handlers.
- Automatic all-grid capture/observer was rolled back because it could freeze a version-induced order. Only explicit manager actions write `CRM_MANAGER_GRID_ORDER_V2`; legacy four-form snapshots remain readable.
- Existing users receive a one-time invoice-status access migration, after which explicit manager permission changes remain authoritative.
- Final permission view is a clean 28-tab map with exact UI names and active details, not historical version buckets.
- Final user CRUD capture-handles save/edit and keeps preset UI idempotent to eliminate missing button and shake regressions.
- Gray dependency styling never colors labels/containers; only controls and related checkbox are dimmed.
## تصمیم ۸۱ — نسخه ۱۱.۲۸.۰: session-id permissions، حذف legacy layout و GPS موازی (2026-08-21)
- Root permission bug: v9 login persisted only crmUserId while later engines searched crmUserName/role. Login now persists all, and `v20CurrentUser` resolves ID first.
- One final permission engine maps all 28 tabs and active sub-controls, restores allowed inline displays, observes new nodes, and replaces old global permission entry points.
- Missing permission means backward-compatible allow; explicit false means deny; manager resolved from current state user bypasses.
- Legacy V1 DOM order is no longer read. Only explicit V2 manager snapshots can reorder. Full/all/custom layout startup calls are all gated.
- Visible configured fields are repaired without un-deleting intentional manager deletions.
- Overlay stacking is globally raised on focus.
- GPS keeps <=10m target, accepts first qualifying fix, runs reverse geocode in parallel, and caps fallback at 15s.
## تصمیم ۸۲ — نسخه ۱۱.۲۹.۰: حذف رقابت permission، قانون parse-time ارقام انگلیسی و ماه نامی Excel (2026-08-21)
- v11 must never hide invoice-status; only final central engine owns it. A fresh one-time V1129 migration repairs already-false rollout values.
- Latin number law installs synchronously before all delayed boot code, wraps Number fa locale to en-US, and Latinizes Date locale output without changing Persian calendar text.
- DOM formatter includes OPTION text and visible placeholder/title attributes while leaving password values unchanged.
- Distributor workbook period metadata maps month number to Persian Jalali month name.
- Every turn continues graph-first, graph regeneration, all archive docs, chat.arena versioning, tests, ZIP and PowerShell.
## تصمیم ۸۳ — نسخه ۱۱.۳۰.۰: pinned invoice tab، mobile all-orientation، universal routing و cross-link persistence (2026-08-21)
- Invoice navigation is permanently pinned. Permission denial hides its card and shows an access message, never removes the tab; V1130 repairs existing users once.
- Mobile max-width 950 handles portrait and landscape; form/list buttons stay 50/50 inside viewport and all action rows wrap.
- Navigation uses provider direction universal links, not map-location/download pages.
- Representative privacy is ownership-first (repId, then exact repName); ownerless records are invisible to normal reps; all-reps requires explicit permission.
- Existing local state remains authoritative. The sole remote-GET exception is a completely empty browser origin, which may bootstrap from the same backend without merging/overwriting.
- Bulk IndexedDB data is mirrored to `/api/bulk` (64MB) for same-backend custom-link continuity; runtime files use persistent disk directory when available.
## تصمیم ۸۴ — نسخه ۱۱.۳۱.۰: cache-before-render، mobile order grid، native intents و user-derived reps (2026-08-21)
- New-build boot is head-first and data-safe: hide shell, delete CacheStorage registrations/assets only, never localStorage/IndexedDB, then one query-version reload.
- Server and SW both bypass stale HTML/JS/CSS caches; UI reveals only after central permissions, eliminating manager flash.
- Mobile order row uses explicit grid areas and compact action buttons; hamburger/drawer have explicit landscape stacking.
- Android navigation uses package intents (`org.rajman.neshan.traffic.tehran.navigator`, `ir.balad`) with directions fallback; iOS keeps universal links.
- `state.users` is authoritative for representative roster. Reps are derived by user ID, preserving live metadata; deleted users cannot survive in rep selectors.
- Activity route fields live on user record and are displayed in cards/selectors.
## تصمیم ۸۵ — نسخه ۱۱.۳۲.۰: Browser/OS sandbox hardening و atomic safe data writes (2026-08-21)
- Legacy inline architecture requires CSP unsafe-inline, but all other CSP boundaries are strict: self default, no object/frame/media/base escape, self form/worker/manifest and HTTPS-only upgrade.
- Permissions Policy denies all unnecessary hardware APIs; geolocation self is the only required sensor.
- CORS wildcard is removed. State-changing same-origin requests require X-CRM-Request plus fetch-site/origin checks.
- All server JSON passes recursive anti-prototype sanitization and atomic mode-0600 writes.
- Client guards block executable/oversized uploads, unsafe protocols, opener access, dangerous drops and HTML control characters.
- Excel formula injection and distributor non-HTTPS URLs are rejected/sanitized.
- No web app can promise absolute OS safety, but browser sandbox and explicit permission boundaries are now maximally constrained without breaking required GPS/files/navigation.
## تصمیم ۸۶ — نسخه ۱۱.۳۳.۰: fixed order products و privacy در تمام گزارش‌های نماینده (2026-08-21)
- Order product identity is catalog-owned: readonly simple input, never datalist/editable dropdown. Counts/gifts/prices remain editable and delegated totals always recalculate.
- Per-row edit/delete are manager-only regardless of stale markup or rerender.
- Privacy is no longer limited to pharmacy/doctor/order lists; old activity/leaves/routes/homes/monthly/targets and v20 route/target paths all project owner-only data.
- Representative selectors are rebuilt after dynamic render and user deletion from state.users-derived reps.
## تصمیم ۸۷ — نسخه ۱۱.۳۴.۰: multi-route manager و target planner کامل (2026-08-21)
- Representative activity routes belong in target management, not user credential form. They support multi province/city/district arrays and derive a display label.
- Standard geography sources are unioned from IRAN_GEO_DATA, manager geoExtras and global semantic option registry.
- Target entry is product-matrix based, not one product dropdown: fixed catalog rows × quantity × current master distributor/pharmacy prices.
- Reports are period-filtered, first all-rep per product then per-rep, with achieved/remain and financial totals.
- Reference field instant-add is disabled in operational forms; manager additions remain the only mutation path.
- Removed-user activity records remain stored but are excluded from every rendered privacy projection.
## تصمیم ۸۸ — نسخه ۱۱.۳۵.۰: acceptance-by-runtime و Web Push threads (2026-08-21)
- Long prompts now require a persisted itemized acceptance checklist; prose without source diff/test is never complete.
- Runtime JSDOM exposed the actual invoice-tab root cause: static HTML was correct but setupNavigationMenu rebuilt from a 27-item canonical list. Fixing canonical MENU_SECTIONS_LIST—not another visibility patch—resolved it.
- Notifications are conversation threads with permission-aware recipients and persisted reply chain.
- Standards Web Push is implemented zero-dependency with persisted VAPID/subscriptions, RFC8291 aes128gcm and OS service-worker notification lifecycle.
- Device sound cannot be forced by a web app; high urgency, vibration and renotify are sent, while audible behavior follows OS/PWA notification settings.
- Mutation guards must be idempotent; observers cannot write the same observed attribute unconditionally.

## تصمیم ۸۹ — نسخه ۱۱.۳۶.۰: قفل تراکنشی فرم سفارش و activity self-only (2026-08-21)
- پاک‌کردن داده فرم حق تغییر layout metadata یا ترتیب فیلدها را ندارد؛ reset با snapshot موقت in-memory و restore چندمرحله‌ای محافظت می‌شود.
- گروه بدون input داخلی باید با id خود گروه در layout anchor ثبت شود؛ حذف چنین گروهی از sequence علت انتقال کادر سفارشی سفارش به ابتدای فرم بود.
- پیام duplicate پس از placement سه لایه hidden/aria/display-important دارد، اما observer فقط هنگام تفاوت واقعی attribute می‌نویسد تا حلقه سفیدشدن برنگردد.
- کنترل‌های route فقط وجود HTML کافی ندارند؛ setup باید در boot و tab activation واقعاً اجرا و با تعداد option در runtime آزموده شود.
- شناسه فنی builtin هرگز label دیداری نیست؛ label مستقیم DOM و registry فارسی بر metadata فنی قدیمی اولویت دارد.
- فعالیت لحظه‌ای از مجوز all-reps نماینده مستثناست: مدیر فعالیت کاربران فعال را می‌بیند، نماینده فقط خودش؛ تاریخچه canonical دست‌نخورده می‌ماند.

## تصمیم ۹۰ — نسخه ۱۱.۳۷.۰: حفاظت پیش از تغییر و final delegated controls (2026-08-21)
- هر تغییر آینده ابتدا backup خواندنی/manifest و آزمون sentinel می‌خواهد؛ state موجود هرگز وارد پاک‌سازی fresh-install نمی‌شود.
- داده نمونه نمایندگان منبع بازگشت کاربران حذف‌شده در origin تازه بود؛ fresh install اکنون blank business state + manager-only است، بدون اثر بر state موجود.
- حذف کاربر یک رویداد durable است و tombstone دارد؛ تاریخچه رکوردها حفظ ولی roster/selector/render از کاربر حذف‌شده پاک می‌شود.
- کنترل‌های dynamic باید delegated final handler داشته باشند؛ bind محلی هنگام ساخت هر نسل کافی نیست.
- حریم خصوصی نقشه به اندازه جدول مهم است؛ visible projection باید هم rows و هم map layers را کنترل کند.
- گیرنده پیام یک reference select است نه searchable/free-typing combo.
- Route manager controls system-owned هستند و metadata stale اجازه پنهان‌کردن آن‌ها را ندارد؛ metadata کاربر بازنویسی نمی‌شود.

## تصمیم ۹۱ — نسخه ۱۱.۳۸.۰: server-truth cache rescue و تحویل واقعی از Git (2026-08-21)
- نسخه‌ای که فقط در sandbox/ZIP است production نیست؛ تحویل واقعی نیازمند commit، push، merge به main و deploy موفق است.
- نسخه سرور از `/api/health` منبع حقیقت build است؛ مقایسه فقط local HTML با localStorage برای کش کاملاً stale کافی نیست.
- Hard reload وب با cache-reset استاندارد پیاده می‌شود: Clear-Site-Data cache + CacheStorage delete + SW unregister + unique URL replace.
- پاک‌سازی cache نباید storage/indexedDB/cookies/data files را شامل شود.
- SW نباید HTML/JS/CSS قدیمی را در حالت network failure برگرداند؛ تازگی نسخه بر offline stale shell اولویت دارد.
- GitHub شاخه ثابت Arena را دریافت می‌کند و تغییر main فقط از Pull Request انجام می‌شود؛ GitLab از workflow main و secrets mirror می‌شود.

## تصمیم ۹۲ — تحویل مستقل برای GitHub review و چت بعدی (2026-08-22)
- chat.arena حافظه کامل و بزرگ است، اما reviewer به یک سند کوتاه‌تر و عملیاتی نیاز دارد؛ `GITHUB_REVIEW_HANDOFF.md` مرجع اول GitHub review شد.
- هر handoff باید تفاوت source-tested، local-committed، branch-pushed، PR-created، main-merged، CI, GitLab, Render و production health را جدا بنویسد.
- خطای مجوز GitHub بخشی از context دائمی است تا مدل بعدی push ناموفق را با deploy موفق اشتباه نگیرد.
- README قدیمی Next.js نباید reviewer را منحرف کند؛ runtime فعلی Node/public در بالای README تصریح شد.

## تصمیم ۹۳ — نوبت ۶۱: انتشار 11.38.0 تأییدشده، مخزن javad-test1 و قانون همگام‌سازی آرشیو (2026-08-22)
- مخزن فعال این چت‌ها `javadalamdarmehraeen-rgb/javad-test1` است و production فعال کاربر `https://javad-test1.onrender.com`؛ سرویس قدیمی `namayandeelmi-javad.onrender.com` دیگر مرجع health نیست و هنوز 11.20.0 است.
- push شاخه Arena وقتی مجاز است که کامیت‌های push حاوی تغییر `.github/workflows/*` نباشند؛ خطای 403 قبلی مخصوص کامیت‌های حاوی workflow بود، نه کل اتصال.
- PR با صفر تفاوت نسبت به main قابل ساخت نیست («No commits between»)؛ اگر نوک شاخه == نوک main باشد، سورس از قبل merged است و ادعای PR معلق غلط است.
- تولید «موفق» در steps ورک‌فلوی deploy بدون لاگ خام معتبر نیست؛ تنها منبع حقیقت انتشار `/api/health` خود production است که این بار 11.38.0 را دو بار مستقل برگرداند و redirect زنده `/login?build=11.38.0&__crm_reload=...` موتور cache rescue را در عمل اثبات کرد.
- ممیزی ۲۰ چت اخیر (نوبت ۴۱–۶۰ = نسخه 11.23.0 تا 11.38.0) با ۲۲ نشانگر کد + 58/58 تست نشان داد هیچ پرامپت معلق‌ای در کد نمانده؛ نسخه برنامه بدون تغییر کد واقعی bump نمی‌شود.
- قانون دائمی جدید (قانون ۹۱ AI_RULES): در هر چت همه ۱۵ فایل آرشیوی به‌روز شوند، graph/chat با اسکریپت‌های خودشان بازسازی شوند و ZIP طبق قانون ۶۴ کنار صفحه بیاید.
- GitLab mirror تنها حلقه تأییدنشده باقی مانده است (remote و لاگ خام از sandbox در دسترس نیست).

## تصمیم ۹۴ — نوبت ۶۲: قانون اجرای جزبه‌جز و راستی‌آزمایی اجباری قبل از تحویل (2026-08-22)
- درخواست تکراری کاربر نباید به پیاده‌سازی دوباره بینجامد؛ الگوی درست: شکستن پرامپت به بندهای شماره‌دار، نگاشت هر بند به فایل/تابع/UI، و راستی‌آزمایی با شواهد کد/رانتایم.
- «وارد شدن خودکار به برنامه» به‌صورت استاندارد تحویل تعریف شد: spawn سرور واقعی + تست app-smoke (health/HTML/اسکریپت/UI حیاتی + حفظ sentinel/vault + VAPID) قبل از ساخت ZIP.
- راستی‌آزمایی نوبت ۶۲: هر ۲۱ بند پرامپت بلند کاربر در نسخه‌های 11.23.0 تا 11.38.0 حاضر بود؛ دو نمونه legacy (u-2/جواد علمدار، u-3/نیلا محرمی) دقیقاً در enforceDeletedUserTombstonesV37 مهاجرت tombstone دارند؛ «از ساعت/تا ساعت» دقیقاً فیلدهای ۵ و ۶ فرم مرخصی‌اند؛ بنابراین هیچ تغییر کدی لازم نبود و نسخه 11.38.0 ماند.
- قالب ثابت بلوک پایان چت (git add/commit با شماره نسخه و خلاصه فارسی/push origin/push gitlab) در قانون ۹۲ بند ۵ ثبت شد.

## تصمیم ۹۵ — نوبت ۶۳: دو سرویس موازی Render علت «ندیدن تغییرات» بود (2026-08-22)
- «تغییرات اعمال نمی‌شود» وقتی health دو دامنه متفاوت است، اول از باز شدن دامنه اشتباه مطمئن شو؛ ظاهر یکسان برنامه‌ها تشخیص چشمی را غیرممکن می‌کند و نشان نسخه هدر باید ملاک باشد.
- PWA نصب‌شده به دامنه‌ای که نصب شده وصل می‌ماند؛ پس با تغییر سرویس، نصب قدیمی باید حذف و از دامنه جدید نصب مجدد شود.
- GitLab mirror و Neon در مسیر deploy سرویس فعلی نیستند؛ زنجیره واقعی: GitHub javad-test1/main → Render autoDeploy.

## تصمیم ۹۶ — نوبت ۶۴: تعویض کامل دامنه در کد و ارتقای واقعی 11.38.1 (2026-08-22)
- وقتی کاربر دامنه فعال را تصریح کرد، همه ثابت‌های دامنه در کد/کانفیگ باید همان‌جا één دامنه شوند؛ گرنه keep-alive/sync/mobile/متن‌ها به سرویس مرده وصل می‌مانند.
- keep_alive باید سرویس فعالِ در حال استفاده را بیدار نگه دارد؛ بیدار نگه‌داشتن سرویس قدیمی فقط هزینه است و سرویس فعال را خواب می‌گذارد (cold start).
- تغییر دامنه در متن‌های کاربرپسند (عیب‌یابی) هم لازم است چون کاربر همان متن را «ثبت‌بودن لینک قدیمی» می‌فهمد.
- ارتقای نسخه فقط با تغییر واقعی کد انجام شد (11.38.1) و انتظارات تست نسخه همگام شدند؛ تست handoff سند را وادار به صدق می‌کند.

## تصمیم ۹۷ — نوبت ۶۵: ترتیب کانونی سفارشات، داینامیک‌سازی لینک و کارایی (2026-08-22)
- ترتیب پیش‌فرض فرم سفارشات کانونی شد (تاریخ اول) و بازنشانی ترتیب ذخیره‌شده فقط با درخواست صریح مدیر و فقط یک‌بار مجاز است؛ قانون «عدم snapshot خودکار» دست‌نخورده ماند.
- هر مقدار دامنه‌دار در کد باید از location.origin/host مشتق شود تا مخازن و لینک‌های Render جدید بدون تغییر کد کار کنند؛ ثابت دامنه فقط fallback است.
- «کندی چند دقیقه‌ای» در سرویس رایگان Render معمولاً خواب سرور است نه حجم کد؛ نگه‌داری بیدار (keep-alive/UptimeRobot) بخشی از راه‌حل انتشار است، نه بهینه‌سازی مرورگر.
- پاسخ به «چرا هر نسخه تنظیمات عوض می‌شود»: موتورهای ۲۷/۸۷/۸۸ تغییر خودکار چیدمان/داده را ممنوع کرده‌اند؛ تغییر معتبر فقط با درخواست صریح کاربر + مهاجرت یک‌باره + تست است.

## تصمیم ۹۸ — نوبت ۶۷: ریشه‌یابی داده‌محور به جای تأیید وجود کد (2026-08-22)
- «وجود تابع در کد» تا وقتی با داده واقعی کاربر آزمایش نشود «کار می‌کند» نیست؛ چهار گزارش کاربر همگی از شکاف بین کد و داده واقعی (بکاپ قدیمی/تطابق دقیق/فقدان بازخورد/فقدان محافظ واقعی) می‌آمدند.
- حذف هویت‌های مدیریت‌حذف‌شده باید دائمی و شناسه‌مستقل (نام نرمال + username + id) باشد؛ ثبت تاریخی حفظ و فقط از دیدار خارج می‌شود.
- گیرندگان پیام نقش‌آگاه است: نماینده فقط مدیر/سرپرست/کارشناس فروش را می‌بیند؛ مدیر همه فعال‌ها.
- کنترل‌های لمس/کلیک باید چند‌مسیره (click+mousedown+pointerdown) با dedupe و بازخورد کاربر باشند.
- محافظت فیلدهای مرجع در لایه نهایی با capture-delegated اجرا می‌شود؛ ادعای سند قدیمی بدون کد، خطای مستندات بود.

## تصمیم ۹۹ — نوبت ۸۰: حلقه‌های خودتغذی MutationObserver را با idempotent کردن کدهای DOM جراحی می‌کنیم، نه با حذف قفل‌های طراحی‌شده (2026-08-25)
- قانون پایه: هر تابعی که با MutationObserver تغذیه می‌شود و خود DOM را می‌نویسد، باید نوشتن را فقط هنگام «تفاوت واقعی» انجام دهد؛ بازنویسی همان ترتیب/همان استایل، حلقه خودتغذی چندهزار جهش‌درثانیه می‌سازد که کل رابط (هر سه تب) را کند، فوكوس تایپ را می‌دزد، لیست کشویی را زیر دست کاربر عوض می‌کند و چیدمان را مدام درهم می‌نماید.
- پنج محافظ دائمی شد: reorderRow فقط وقتی سلول واقعاً باید جابه‌جا شود (`cells[i] !== cells[finalOrder[i]]`)؛ restoreOrderFormSequence و restoreDomFieldOrder با مقایسه currentIds/desiredIds؛ ناظر قفل موقعیت فرم سفارش فقط برای تغییرات ساختاری واقعی (که `.crm-combo-list` نیست) با آزادسازی آسنکرون busy؛ ناظر دسترسی مرکزی لیست کشویی را جهش معتبر نمی‌داند؛ قفل طوسی v49 با dataset flag idempotent شد.
- قفل‌های طراحی‌شده قبلی (خاکستری اطلاعات داروخانه در سفارشات، زنجیره استان→شهر→منطقه، ترتیب کانونی، محافظ مرجع غیرمدیر) رفتار طراحی‌شده کاربر هستند و دست‌نخورده ماندند؛ تشخیص بین «قفل ویژگی» و «حلقه خزش DOM» الزامی است.
- روش تحقیق الزامی: اجرای واقعی UI (سرور + JSDOM) با سنجش کمی جهش DOM به‌جای حدس از روی خواندن کد؛ معیار پذیرش: جهش بیکار = صفر و پایداری انتخاب/تایپ به‌صورت End-to-End.

## تصمیم ۱۰۰ — نوبت ۸۱: نام داروخانه/پزشک فیلد ساده است؛ افزودن لحظه‌ای ویژگی همان دو تب است نه همه برنامه (2026-08-25)
- «فیلد ساده» یعنی INPUT متنی بدون datalist/کشویی؛ دکمه افزودن لحظه‌ای کنار همان فیلد مجاز است تا نام جدید ذخیره شود، ولی کشویی باز نمی‌شود.
- افزودن لحظه‌ای سراسری (سفارشات/کالا/همه inputها) باعث شلوغی و قفل ظاهری فیلدها می‌شد؛ از این نوبت فقط `#tab-pharmacies` و `#tab-doctors`.
- پلاک و طبقه جزء آدرس‌اند نه جزء «درصدی بودن»؛ هرگز داخل کادر زرد درصد قرار نمی‌گیرند.

## تصمیم ۱۰۱ — نوبت ۸۲ (2026-08-25)
- نام داروخانه/پزشک هرگز کشویی/datalist/افزودن لحظه‌ای نمی‌گیرند.
- افزودن لحظه‌ای روی فیلد متنی سراسری ممنوع است؛ شلوغی و شکستن چیدمان می‌آورد.
- فرم پزشک/داروخانه باید گرید ثابت ۳ستونه باشد نه auto-fit/flex sized.
- فیلد نام داروخانه در سفارشات باید روی فوکوس همه داروخانه‌های ثبت‌شده را نشان بدهد، نه فقط پس از ۲ حرف.

## تصمیم ۱۰۲ — نوبت ۸۳ (2026-08-25)
اندازه فیلد فقط با طراح مدیر؛ نام داروخانه/پزشک هرگز list نمی‌گیرد؛ جستجوی سفارشات لحظه‌ای و انتخاب‌پذیر است.

## تصمیم ۱۰۳ — نوبت ۸۴
اطلاعات چندکاربره باید روی سرور یکی باشد. localStorage فقط کش است. POST ادغام می‌کند نه overwrite.

## تصمیم ۱۰۴ — نوبت ۸۵
مسیر نماینده با چک‌باکس چندانتخابی در تب مستقل است. تارگت پخش از تارگت نماینده جدا شد.

## تصمیم ۱۰۵ — نوبت ۸۶: کانال تحویل ZIP باید فرمت ویندوز + صفحه HTML باشد (2026-08-26)
- present_file روی `.zip` در Arena ممکن است سفید/باینری/فایل‌های جدا دیده شود؛ این پیش‌نمایش است نه خود فایل.
- ZIP تحویلی باید PKZIP سازگار با Explorer/WinRAR باشد (`create_system=0`).
- کانال قطعی دانلود: سرور پورت 8000 با صفحه فارسی و `Content-Disposition: attachment`.
- بدون تغییر کد برنامه، نسخه bump نمی‌شود.

## تصمیم ۱۰۶ — نوبت ۸۷: اندازه ذخیره‌شده مدیر اعمال می‌شود؛ همگام‌سازی با زمان تازه‌تر است
- قفل چیدمان نباید اندازهٔ صریح مدیر را پاک کند.
- ادغام چنددستگاه باید رکورد تازه‌تر را ببرد، نه «محلی همیشه برنده».
- GET دوره‌ای و اعمال پاسخ POST برای برنامهٔ آنلاین الزامی است.


## تصمیم نوبت ۸۸ — 11.68.0
جدول عملیات تارگت باید بیرون از hostی باشد که با innerHTML بازنویسی می‌شود. فاصله فیلدها بر حسب میلی‌متر (96/25.4 px) و شماره سطر با گروه‌بندی flex اعمال می‌شود.

## 11.69.0 / نوبت ۸۹
سرور منبع حقیقت است؛ حذف با _deletedIds روی ادغام اعمال می‌شود؛ رکوردهای هم‌نام ادغام می‌شوند؛ poll سبک ۲۵ثانیه؛ ویرایش/حذف تارگت و فاصله/سطر زنده.

## 11.70.0 / نوبت ۹۰
حلقه cache-reset قطع شد. سرور فقط اطلاعات همین دستگاه را نگه می‌دارد (_soloOnly / replace).

## 11.71.0 / نوبت ۹۱
اسکریپت یک‌بار؛ ۴۰۴ بدون login.html؛ سرور فقط داده همین دستگاه.

## 11.72.0 / نوبت ۹۲
علت نشان‌دادن دادهٔ سیستم‌های دیگر در باز شدن: رندر اولیه از localStorage و ادغام دیرهنگام سرور بدون re-render. تصمیم: adopt کامل سرور و رسم فوری لیست‌ها. ویرایش/حذف روی‌هم‌رفتهٔ v67/v68/v69 با یک handler خنثی شد.

## 11.73.0 / نوبت ۹۳
دو شیء state + پرده ۸۰۰ms علت نشان‌دادن دادهٔ دیگران بود. نقاشان v68/v69 دکمه‌ها را می‌ساختند و hide پنهان می‌کرد. v66 save روی window.state جدا یا match ماه اشتباه ذخیره را از دست می‌داد. تصمیم: bind زنده + unveil بعد adopt + kill host قدیمی + saveDistTargetsV73.

## 11.74.0 / نوبت ۹۴
مشاطب تا کنون schema ثابت نداشت و از حدس هدر استفاده می‌کرد. تصمیم: ایندکس قطعی ستون‌ها + نقشه کد مثل شفاآراد.

## 11.75.0 / نوبت ۹۵
v64lockLayout بعد از apply اندازه را پاک می‌کرد. v56routeGeoFilter هر ۲٫۵ثانیه option شهر/استان را حذف می‌کرد. Combo متنی Chrome Autofill می‌آورد. تصمیم: اعمال مجدد meta، قطع interval، hardening combo، locationDup سخت.

## 11.78.0
قیمت مصرف‌کننده، مارژین قانونی (to-from)/to، ویرایش VAT هر سطر، طراح زنده بدون به‌هم‌ریختن سفارشات، اعمال لحظه‌ای ذخیره بدون رفرش.

## 11.79.0
فقط اطلاعات همین دستگاه؛ ستون تکراری کد کالا حذف شد؛ پاکسازی فایل اضافی در بلوک پاورشل پایان چت.

## 11.80.0
ملاک فقط سرور؛ قفل POST نسخه‌های قبلی؛ حذف داده نمونه از کد؛ مصرف‌کننده جدید از فعلی × افزایش.

## 11.81.0
پاکسازی قطعی داده سیستم قبلی روی ارتقا؛ قفل POST قدیمی؛ مصرف‌کننده جدید مستقل از داروخانه.

## 11.82.0
طراح ستون‌ها باید روی فرم واقعی اعمال شود؛ snapshot قفل ترتیب HTML دیگر meta را خنثی نکند. فقط فرزندان سطح اول گرید جابه‌جا شوند.

## 11.83.0
appendChild فرم هنگام فوکوس ورودی ممنوع. کاشی OSM از طریق پروکسی سرور. ورود موبایل روی localStorage.

## 11.84.0
داشبورد زنده با فیلتر. Layout فقط CSS order. Observer سفارشات دیگر snapshot HTML را برنمی‌گرداند.

## 11.85.0
دکمه عملیات مسیر از v68/v72/v73 تکراری می‌شد؛ یک سلول نگه داشته شد. جغرافیا: جستجو + همه. داشبورد برچسب کامل.

## 11.89.0
پاکسازی نسل ۱۱.۸۱ داروخانه واقعی را هم می‌کشت. قانون جدید: هرگز آرایه‌های عملیاتی کاربر خالی نشود.

## نوبت ۱۰۸ — نسخه ۱۱.۹۰.۰ (۲۰۲۶-۰۸-۲۸)
موبایل سفید/همبرگری، تخصص پزشک، حریم نماینده، رصد تردد یک‌باره، کلید استاندارد.

## نوبت ۱۰۹ — نسخه ۱۱.۹۱.۰
محتوای موبایل سفید رفع، تخصص کامل در فیلد، ویرایش/حذف مسیر، فاصله فشرده داشبورد.

## نوبت ۱۱۰ — نسخه ۱۱.۹۲.۰
هاب ndcohub.ir و mehraeinpharma.ir + Render؛ CORS؛ همگام ذخیره؛ رفع ۴۰۴ favicon و مسیر login/panel فایل.

## نوبت ۱۱۱ — نسخه ۱۱.۹۳.۰
حالت fullstack/static، sync-all.js، build-static نت‌افراز، هاب env، timeout/retry. بدون Next.js.

## نوبت ۱۱۲ — نسخه ۱۱.۹۴.۰
نت‌افراز مستقل با api.php، leaflet ریشه، همگام اختیاری Render، راهنمای SSL.

## نوبت ۱۱۳ — نسخه ۱۱.۹۵.۰
نشان نسخه کنار لوگو با کادر ورود یکی شد (دیگر ۹۱ روی ۹۴/۹۵ نمی‌نشیند). نت‌افراز دیگر داده رندر را بی‌اجازه نمی‌کشد. نام پیش‌فرض شرکت طنین طب طاها. داروخانه کاربر خالی نمی‌شود.

## نوبت ۱۱۴ — نسخه ۱۱.۹۶.۰
مسیر /api/sync در api.php برای ارسال داده نت‌افراز به رندر. push_render با نسل ۱۱.۸۱ و هدر X-CRM-Sync تا رندر رد نکند. ذخیره خالی رندر را پاک نمی‌کند.

## نوبت ۱۱۵ — نسخه ۱۱.۹۷.۰
آپلود فایل جدید دیگر داده قدیمی نت‌افراز را نگه نمی‌دارد: با نسخه جدید، داده از رندر جایگزین می‌شود (اگر رندر خالی نباشد). npm run build-static پیش‌فرض BASE_URL رندر را می‌نویسد.

## نوبت ۱۱۶ — نسخه ۱۱.۹۸.۰
سرویس‌ورکر دیگر بدون Response رد نمی‌شود. Options از htaccess برداشته شد تا نت‌افراز ۵۰۰ ندهد. api-config معتبر PHP/JSON. نشان نسخه واحد.

## نوبت ۱۱۷ — نسخه ۱۱.۹۹.۰
نت‌افراز مستقل و سریع. فایل/حافظه قدیمی خوانده نمی‌شود. همگام فقط پس‌زمینه. GET دیگر رندر را صبر نمی‌کند.

## نوبت ۱۱۸ — نسخه ۱۲.۰۰.۰
Forbidden نت‌افراز با index.php رفع شد. نشان کنار لوگو با سرور یکی است. نام شرکت قدیمی به طنین طب طاها برمی‌گردد. داده عملیاتی کاربر پاک نمی‌شود.

## نوبت ۱۱۹ — نسخه ۱۲.۰۱.۰
گواهی ndcohub دیگر کنسول رندر را پر نمی‌کند. کاشی نقشه نت‌افراز از OSM. همگام خودکار: اول از رندر می‌کشد بعد می‌فرستد.

## نوبت ۱۲۰ — نسخه ۱۲.۰۲.۰
همگام فقط از نت‌افراز به رندر. بازیابی فقط داده ثبت‌شده. موبایل فشرده. بدون fetch کورس به نت‌افراز.

## نوبت ۱۲۱ — نسخه ۱۲.۰۳.۰
آپلود نسخه جدید داده ثبت‌شده را پاک نمی‌کند. فایل زنده هاست در static-build نیست. همگام ادغام است.

## نوبت ۱۲۲ — نسخه ۱۲.۰۴.۰
داده زنده در پوشه data است نه کنار فایل‌های JS.

## نوبت ۱۲۳ — نسخه ۱۲.۰۵.۰
static-build فقط فایل. داده خالی از رندر پر می‌شود.

## نوبت ۱۲۴ — نسخه ۱۲.۰۶.۰
ویندوز و گوشی یک داده از api.php نت‌افراز. ذخیره واقعی روی هاست نه فقط حافظه مرورگر.

## نوبت ۱۲۵ — نسخه ۱۲.۰۷.۰
هدر چسبان موبایل، تکراری داروخانه با نام، اعتبارسنجی ستاره، منطقه، مسیر، منزل با ذخیره، قیمت رند ۵/۱۰.

## نوبت ۱۲۶ — نسخه ۱۲.۰۸.۰
رفرش داده را پاک نمی‌کند. ستاره فقط فیلد ستاره‌دار. تخصص یک فیلد. جغرافیا ثابت. منزل GPS. قیمت بدون VAT دوبل.

## نوبت ۱۲۷ — نسخه ۱۲.۰۹.۰
نام و جای فیلد بین ویندوز و گوشی. مصرف‌کننده با ارزش افزوده در قیمت جدید قابل ویرایش. تخصص لیست+جستجو. GPS منزل.

## تصمیم ۱۰۶ — نوبت ۱۲۸: رفع سه نقص، سربرگ سه‌خطی، استقلال از VPN، همگام سه دامنه (2026-08-31)

- ممیزی نسخه روی گیت‌هاب نشان داد ۱۲.۰۹.۳ در چهار فایل (server.js/sw.js/login.html/crm-hub.js)
  عقب مانده بود؛ تصمیم: نسخه واحد `12.16.0` در همه فایل‌های کد، دارایی‌ها و PHP.
- `public/index.php` در مخزن نبود در حالی که اسناد ادعا می‌کردند ۴۰۳ رفع شده؛
  تصمیم: ساخت فایل با سروِ مستقیم `index.html` (بدون ریدایرکت/حلقه) + ثبت در فایل‌رسمی.
- ۴۵ تست قرمزِ نسخه قبلی عمدتاً به‌خاطر کهنه شدن رشته نسخه در انتظارات بود؛
  تصمیم: انتظارات با نسخه همگام شوند، نه اینکه کد به عقب برگردد.
- وابستگی به VPN: ریشه در تایم‌اوت‌های ۲۰ ثانیه‌ایِ فراخوانی رندر و نبود مدیریت
  خطا برای کاشی/ژئوکد بود؛ تصمیم: لایه `v12.16.0` با تایم‌اوت ۶ ثانیه،
  ارسال فقط در پس‌زمینه، و پیام‌های غیرمسدودکننده.
- دامنه سوم `ndcohub.com` به نت‌افراز افزوده شد؛ تصمیم: همگام سه‌طرفه
  (مرورگر + `api.php?target=all`) با ادغام شناسه‌محور و حذف `ndcohub.ir`
  به‌دلیل گواهی نامعتبر.
- نشان نسخه به ارقام لاتین تغییر کرد (درخواست صریح کاربر) و نام شرکت
  کانونی شد: `برنامه ویزیت و گزارشات (مهر آیین نیک دارو)`.
